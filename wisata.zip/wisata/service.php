<?php
header("Content-Type: application/xml; charset=UTF-8");
include 'koneksi.php';

$id = isset($_GET['id']) ? $_GET['id'] : '';
$nama = isset($_GET['nama']) ? $_GET['nama'] : '';

$query = "SELECT * FROM wisata_sem WHERE 1";

if($id) {
    $query .= " AND id='$id'";
}

if($nama) {
    $query .= " AND nama='$nama'";
}

$result = mysqli_query($koneksi, $query);
if (!$result) {
    die('Query error: ' . mysqli_error($koneksi));
}

$xml = new SimpleXMLElement('<data_wisata_sem/>');

while ($row = mysqli_fetch_assoc($result)) {
    $wisata_sem = $xml->addChild('wisata_sem');
    $wisata_sem->addChild('id', $row['id']);
    $wisata_sem->addChild('nama', $row['nama']);
    $wisata_sem->addChild('alamat', $row['alamat']);
    $wisata_sem->addChild('kategori', $row['kategori']);
}

echo $xml->asXML();

//menambah data
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'tambah') {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $kategori = $_POST['kategori'];

    $query = "INSERT INTO wisata_sem (nama, alamat, kategori) VALUES ('$nama', '$alamat', '$kategori')";
    if (mysqli_query($koneksi, $query)) {
        echo "<response> Data berhasil ditambahkan! </response>";
    } else {
        echo "<error> Error: " . mysqli_error($koneksi) . " </error>";
    }
    exit;
}

//mengedit data
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'edit') {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $kategori = $_POST['kategori'];

    $query = "UPDATE wisata_sem SET nama='$nama', alamat='$alamat', kategori='$kategori' WHERE id=$id";
    if (mysqli_query($koneksi, $query)) {
        echo "<response> Data berhasil diupdate! </response>";
    } else {
        echo "<error> Error: " . mysqli_error($koneksi) . " </error>";
    }
    exit;
}

//menghapus data
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'hapus') {
    $id = $_POST['id'];

    $query = "DELETE FROM wisata_sem WHERE id=$id";
    if (mysqli_query($koneksi, $query)) {
        echo "<response> Data berhasil dihapus! </response>";
    } else {
        echo "<error> Error: " . mysqli_error($koneksi) . " </error>";
    }
    exit;
}
?>