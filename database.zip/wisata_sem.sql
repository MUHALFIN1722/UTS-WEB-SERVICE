-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2023 at 05:17 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wisata`
--

-- --------------------------------------------------------

--
-- Table structure for table `wisata_sem`
--

CREATE TABLE `wisata_sem` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `kategori` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wisata_sem`
--

INSERT INTO `wisata_sem` (`id`, `nama`, `alamat`, `kategori`) VALUES
(1, 'Lawang Sewu', 'Jl. Pandanaran No.2', 'Sejarah'),
(2, 'Kota Lama', 'Jl. Letjen Suprapto', 'Sejarah'),
(3, 'Tugu Muda', 'Jl. Pemuda, Sekayu, Kec. Semarang Tengah, Kota Semarang, Jawa Tengah 50132', 'Sejarah'),
(4, 'Kampung Pelangi', 'Jl. Wonosari Lor No.1, Wonosari Lor, Pedurungan, Kota Semarang, Jawa Tengah 50192', 'Tempat Foto'),
(5, 'Candi Gedong Songo', 'Gedongsongo, Candi RT04/RW09, Banyumanik, Semarang, Central Java 50266', 'Sejarah'),
(6, 'Lawang Sewu Light Festival', 'Jl. Pandanaran No.2, Sumurbandung, Kec. Semarang Tengah, Kota Semarang, Jawa Tengah 50233', 'Event Wisata'),
(7, 'Pasar Pecinan Semawis', 'Jl. Kranggan Dalam Jl. Gg. Warung No.50, Kauman, Kec. Semarang Tengah, Kota Semarang, Jawa Tengah 50', 'Event Wisata'),
(8, 'Curug Lawe', 'Ngaliyan, Semarang', 'Wisata Alam'),
(9, 'Umbul Sidomukti', 'Ambarawa, Semarang', 'Wisata Alam'),
(10, 'Masjid Agung Jawa Tengah', 'Gajahmungkur, Semarang', 'Religi'),
(11, 'Puncak Gedong Songo', 'Ambarawa, Semarang', 'Wisata Alam'),
(12, 'Soto Bangkong', 'Pemuda, Semarang', 'Kuliner'),
(13, 'Lumpia Semarang', 'Gajahmungkur, Semarang', 'Kuliner'),
(14, 'Ikan Bakar Cianjur', 'Gunung Pati, Semarang', 'Kuliner'),
(15, 'Gereja Blenduk', 'Old Town, Semarang', 'Sejarah & Budaya'),
(16, 'Brown Canyon', 'Tembalang, Semarang', 'Wisata Alam'),
(17, 'Museum Kereta Ambarawa', 'Ambarawa, Semarang', 'Sejarah'),
(18, 'Pasar Johar', 'Tugu Muda, Semarang', 'Wisata Perbelanjaan'),
(19, 'Trans Studio Mall Semarang', 'Gajahmungkur, Semarang', 'Wisata Hiburan'),
(20, 'Vihara Buddhagaya Watugong', 'Gajahmungkur, Semarang', 'Religi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wisata_sem`
--
ALTER TABLE `wisata_sem`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wisata_sem`
--
ALTER TABLE `wisata_sem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
